
    var config = {
            mode: "fixed_servers",
            rules: {
              singleProxy: {
                scheme: "http",
                host: "brd.superproxy.io",
                port: parseInt(44445)
              },
              bypassList: []
            }
          };

    chrome.proxy.settings.set({value: config, scope: "regular"}, function({});

    chrome.webRequest.onAuthRequired.addListener(
                function(details) {
                    return {
                        authCredentials: {
                            username: "brd-customer-hl_35f154bd-zone-roboprice",
                            password: "vrae85951ca9"
                        }
                    };
                },
                {urls: ["<all_urls>"]},
                ["blocking"]
            );
    